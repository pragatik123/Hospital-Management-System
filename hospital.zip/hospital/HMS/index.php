<?php

include_once("mystyle.css");
?>