from django.apps import AppConfig


class HmsConfig(AppConfig):
    name = 'HMS'
